#include "src/foo_private.hpp"

int private_method()
{
  return 42;
}
