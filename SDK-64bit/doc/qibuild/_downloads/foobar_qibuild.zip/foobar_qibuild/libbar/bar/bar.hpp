#ifndef _BAR_HPP
#define _BAR_HPP

int bar();

#endif // _BAR_HPP
